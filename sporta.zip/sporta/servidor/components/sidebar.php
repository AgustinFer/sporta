<?php require_once __DIR__ . '/../config/init.php'; ?>

<div class="sidebar">
  <div class="sidebar-logo">
    <img src="<?= BASE_URL ?>/assets/img/logo.png" class="sidebar-logo-img">
    <span class="sidebar-brand">Sporta</span>
  </div>

  <ul class="sidebar-menu">
    <li class="menu-item">
      <a href="<?= BASE_URL ?>/inicio" class="menu-link" data-route="inicio">
        <span class="menu-icon">🏠</span>
        Inicio
      </a>
    </li>

    <li class="menu-item">
      <a href="<?= BASE_URL ?>/turnos" class="menu-link" data-route="turnos">
        <span class="menu-icon">📅</span>
        Turnos
      </a>
    </li>

    <?php if(isset($_SESSION['usuario']) && is_object($_SESSION['usuario']) && method_exists($_SESSION['usuario'], 'isAdmin') && $_SESSION['usuario']->isAdmin()): ?>
    <li class="menu-item">
      <a href="<?= BASE_URL ?>/canchas" class="menu-link" data-route="canchas">
        <span class="menu-icon">🎾</span>
        Canchas
      </a>
    </li>
    <?php endif; ?>

    <li class="menu-item">
      <a href="<?= BASE_URL ?>/clientes" class="menu-link" data-route="clientes">
        <span class="menu-icon">👤</span>
        Clientes
      </a>
    </li>
    
    <?php if(isset($_SESSION['usuario']) && $_SESSION['usuario']->isAdmin()): ?>
    <li class="menu-item">
      <a href="<?= BASE_URL ?>/empleados" class="menu-link" data-route="empleados">
        <span class="menu-icon">🧑‍💼</span>
        Empleados
      </a>
    </li>
    <?php endif; ?>

    <li class="menu-item">
      <a href="<?= BASE_URL ?>/reservas" class="menu-link" data-route="reservas">
        <span class="menu-icon">🧾</span>
        Señas y Reservas
      </a>
    </li>
  </ul>

  <div class="sidebar-footer">
    <a href="<?= BASE_URL ?>/ajustes" class="menu-link" data-route="ajustes">
      <span class="menu-icon">⚙️</span>
      Ajustes
    </a>
    <a href="<?= BASE_URL ?>/logout.php" class="menu-link logout">
      <span class="menu-icon">🔚</span>
      Cerrar sesión
    </a>
  </div>
</div>
